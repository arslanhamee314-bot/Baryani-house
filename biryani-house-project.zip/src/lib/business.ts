export const business = {
  name: "Biryani House",
  tagline: "Fresh, Flavorful Biryani in the Heart of Jauharabad",
  category: "Biryani Restaurant",
  phone: "+92 454 723523",
  phoneTel: "+924547 23523",
  phoneHref: "tel:+924547235233".replace(/\s/g, ""), // safe tel
  whatsapp: "+924547235233", // editable placeholder
  address: {
    line1: "77PJ+W32, Main Bazar Road",
    line2: "Main Bazar, Jauharabad",
    region: "Punjab",
    country: "Pakistan",
  },
  hoursLabel: "Daily 8:00 AM – 11:00 PM",
  hoursSchema: "Mo-Su 08:00-23:00",
  rating: 3.9,
  mapsQuery: "Biryani House, Main Bazar Road, Jauharabad, Punjab, Pakistan",
} as const;

export const callHref = `tel:${business.phone.replace(/[^\d+]/g, "")}`;
export const directionsHref = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(business.mapsQuery)}`;
export const mapEmbedSrc = `https://www.google.com/maps?q=${encodeURIComponent(business.mapsQuery)}&output=embed`;
export const whatsappHref = `https://wa.me/${business.whatsapp.replace(/[^\d]/g, "")}`;
export const googleReviewsHref = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(business.mapsQuery)}`;
