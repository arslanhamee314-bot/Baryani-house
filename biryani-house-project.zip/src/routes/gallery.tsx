import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHero, PageLayout, PlaceholderChip } from "@/components/site/PageLayout";
import { Reveal } from "@/components/site/Reveal";
import { gallery, type GalleryItem } from "@/data/gallery";

const CATEGORIES = ["All", "Food", "Interior", "Service"] as const;

export const Route = createFileRoute("/gallery")({
  head: () => ({
    meta: [
      { title: "Gallery | Biryani House Jauharabad" },
      { name: "description", content: "Photos of biryani, karahi, our dining room and daily service at Biryani House in Main Bazar, Jauharabad." },
      { property: "og:title", content: "Gallery | Biryani House Jauharabad" },
      { property: "og:description", content: "Photos of biryani, karahi, our dining room and daily service at Biryani House." },
      { property: "og:url", content: "/gallery" },
    ],
    links: [{ rel: "canonical", href: "/gallery" }],
  }),
  component: GalleryPage,
});

function GalleryPage() {
  const [filter, setFilter] = useState<(typeof CATEGORIES)[number]>("All");
  const items = useMemo<GalleryItem[]>(
    () => (filter === "All" ? gallery : gallery.filter((g) => g.category === filter)),
    [filter],
  );

  return (
    <PageLayout>
      <PageHero
        eyebrow="Gallery"
        title="Food, room and everyday service"
        subtitle="Placeholder photography shown — replace with your own approved photos any time."
      />

      <section className="container-page py-12">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((c) => (
              <button
                key={c}
                onClick={() => setFilter(c)}
                className={`px-4 py-2 rounded-full text-sm font-semibold border transition ${
                  filter === c
                    ? "bg-[color:var(--primary)] text-white border-[color:var(--primary)]"
                    : "bg-[color:var(--surface)] text-[color:var(--foreground)] border-[color:var(--border)] hover:border-[color:var(--primary)]/40"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
          <PlaceholderChip>Photos are editable</PlaceholderChip>
        </div>

        <div className="mt-8 grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-5">
          {items.map((it, i) => (
            <Reveal key={it.src + i} delay={(i % 6) * 0.04}>
              <figure className={`group relative overflow-hidden rounded-2xl border border-[color:var(--border)] ${i % 5 === 0 ? "md:row-span-2 md:aspect-[3/4]" : "aspect-square"}`}>
                <img src={it.src} alt={it.alt} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                <figcaption className="absolute inset-x-0 bottom-0 p-3 text-xs text-white font-medium bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                  {it.category}
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </section>
    </PageLayout>
  );
}
