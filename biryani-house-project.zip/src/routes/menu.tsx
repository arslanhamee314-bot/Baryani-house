import { createFileRoute } from "@tanstack/react-router";
import { Phone } from "lucide-react";
import { PageLayout, PageHero, PlaceholderChip } from "@/components/site/PageLayout";
import { Reveal } from "@/components/site/Reveal";
import { callHref } from "@/lib/business";
import { featuredDishes, menuCategories } from "@/data/menu";

export const Route = createFileRoute("/menu")({
  head: () => ({
    meta: [
      { title: "Menu | Biryani House Jauharabad" },
      { name: "description", content: "Signature biryani, karahi, sides and desserts at Biryani House, Main Bazar, Jauharabad. Call +92 454 723523 to order." },
      { property: "og:title", content: "Menu | Biryani House Jauharabad" },
      { property: "og:description", content: "Signature biryani, karahi, sides and desserts. Call to order for pickup or dine in daily 8am–11pm." },
      { property: "og:url", content: "/menu" },
    ],
    links: [{ rel: "canonical", href: "/menu" }],
  }),
  component: MenuPage,
});

function MenuPage() {
  return (
    <PageLayout>
      <PageHero
        eyebrow="The Menu"
        title="Slow-cooked biryani and honest sides"
        subtitle="All prices shown are editable placeholders. Update them in one place — no rebuild needed for content changes."
      />

      <section className="container-page py-16 md:py-20">
        <Reveal>
          <h2 className="font-display">Featured</h2>
          <p className="mt-2 text-[color:var(--muted-foreground)] max-w-2xl">Our house biryani and a few kitchen favourites.</p>
        </Reveal>
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {featuredDishes.map((d, i) => (
            <Reveal key={d.name} delay={i * 0.05}>
              <article className="card-surface overflow-hidden h-full flex flex-col">
                {d.image && (
                  <div className="aspect-[4/3] overflow-hidden">
                    <img src={d.image} alt={d.name} loading="lazy" className="h-full w-full object-cover" />
                  </div>
                )}
                <div className="p-5 flex-1 flex flex-col">
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="font-display text-xl">{d.name}</h3>
                    <span className="font-semibold text-[color:var(--primary)] whitespace-nowrap">{d.price}</span>
                  </div>
                  <p className="mt-2 text-sm text-[color:var(--muted-foreground)] leading-relaxed">{d.description}</p>
                  <div className="mt-4 flex items-center justify-between">
                    <PlaceholderChip>Editable</PlaceholderChip>
                    <a href={callHref} className="text-sm font-semibold text-[color:var(--primary)] inline-flex items-center gap-1 hover:gap-2 transition-all">
                      <Phone className="h-3.5 w-3.5" /> Call to order
                    </a>
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="container-page pb-24 space-y-16">
        {menuCategories.map((cat, ci) => (
          <Reveal key={cat.title} delay={ci * 0.05}>
            <div>
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-3 border-b border-[color:var(--border)] pb-4">
                <div>
                  <h2 className="font-display text-[color:var(--foreground)]">{cat.title}</h2>
                  {cat.note && <p className="mt-1 text-sm text-[color:var(--muted-foreground)]">{cat.note}</p>}
                </div>
                <a href={callHref} className="btn-ghost text-sm">
                  <Phone className="h-4 w-4" /> Call to order
                </a>
              </div>
              <ul className="mt-6 divide-y divide-[color:var(--border)]">
                {cat.items.map((item, ii) => (
                  <li key={`${cat.title}-${ii}`} className="py-5 grid grid-cols-[minmax(0,1fr)_auto] gap-6 items-start">

                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-display text-lg text-[color:var(--foreground)]">{item.name}</h3>
                        {item.editable && <PlaceholderChip>Editable</PlaceholderChip>}
                      </div>
                      <p className="mt-1 text-sm text-[color:var(--muted-foreground)] leading-relaxed">{item.description}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="font-display text-xl font-semibold text-[color:var(--primary)]">{item.price}</span>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        ))}
      </section>

      <FinalCta />
    </PageLayout>
  );
}

function FinalCta() {
  return (
    <section className="container-page pb-20">
      <div className="rounded-3xl bg-[color:var(--primary)] text-[color:var(--primary-foreground)] p-8 md:p-12 text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_20%_20%,white_0,transparent_50%)]" />
        <h2 className="font-display relative">Hungry? Call us and we'll have it ready.</h2>
        <p className="mt-3 text-white/85 max-w-xl mx-auto relative">Speak directly with the kitchen. One call, no apps, no middlemen.</p>
        <a href={callHref} className="relative inline-flex mt-6 items-center gap-2 rounded-full bg-white text-[color:var(--primary)] px-6 py-3 font-semibold hover:bg-white/90 transition">
          <Phone className="h-4 w-4" /> Call +92 454 723523
        </a>
      </div>
    </section>
  );
}
