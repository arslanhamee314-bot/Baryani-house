import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Clock,
  Accessibility,
  MapPin,
  Phone,
  Star,
  Utensils,
  Flame,
} from "lucide-react";
import heroImg from "@/assets/hero-biryani.jpg";
import interiorImg from "@/assets/gallery-interior-1.jpg";
import servingImg from "@/assets/gallery-serving.jpg";
import spicesImg from "@/assets/gallery-spices.jpg";
import thaliImg from "@/assets/gallery-thali.jpg";
import { business, callHref, directionsHref, googleReviewsHref, mapEmbedSrc } from "@/lib/business";
import { PageLayout, PlaceholderChip, SectionHeader } from "@/components/site/PageLayout";
import { Reveal } from "@/components/site/Reveal";
import { featuredDishes } from "@/data/menu";
import { faqs } from "@/data/faqs";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Biryani House | Biryani Restaurant in Jauharabad" },
      { name: "description", content: "Fresh, flavorful biryani in Main Bazar, Jauharabad. Dine-in and takeaway daily 8am–11pm. Call +92 454 723523 to order or get directions." },
      { property: "og:title", content: "Biryani House | Biryani Restaurant in Jauharabad" },
      { property: "og:description", content: "Fresh, flavorful biryani in Main Bazar, Jauharabad. Dine-in and takeaway daily 8am–11pm." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <PageLayout>
      <Hero />
      <TrustStrip />
      <SignatureMenu />
      <WhyUs />
      <AboutPreview />
      <GalleryPreview />
      <ReviewsPreview />
      <FaqPreview />
      <ContactMap />
    </PageLayout>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-gradient-to-br from-[color:var(--background)] via-[color:var(--surface)] to-[#F1E7DA]" />
      <div className="absolute -top-32 -left-32 h-96 w-96 rounded-full bg-[color:var(--primary)]/8 blur-3xl -z-10" />
      <div className="absolute -bottom-32 -right-32 h-96 w-96 rounded-full bg-[color:var(--secondary)]/10 blur-3xl -z-10" />

      <div className="container-page pt-10 pb-16 md:pt-16 md:pb-24 grid gap-10 lg:grid-cols-[1.05fr_1fr] items-center">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="eyebrow"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--secondary)]" />
            Biryani · Karahi · Dine-in & Takeaway
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.05 }}
            className="mt-4 font-display text-[color:var(--foreground)]"
          >
            Fresh, Flavorful{" "}
            <span className="text-[color:var(--primary)]">Biryani</span> in the Heart of{" "}
            <span className="italic text-[color:var(--secondary-hover)]">Jauharabad</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="mt-5 text-lg text-[color:var(--muted-foreground)] leading-relaxed max-w-xl"
          >
            Slow-cooked biryani, warm hospitality and honest local flavour on Main Bazar Road. Call to order for pickup, or drop in for dine-in — open daily from 8am to 11pm.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.25 }}
            className="mt-8 flex flex-wrap items-center gap-3"
          >
            <a href={callHref} className="btn-primary">
              <Phone className="h-4 w-4" /> Call to Order
            </a>
            <a href={directionsHref} target="_blank" rel="noreferrer" className="btn-ghost">
              <MapPin className="h-4 w-4" /> Get Directions
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.35 }}
            className="mt-8 flex flex-wrap items-center gap-6 text-sm text-[color:var(--muted-foreground)]"
          >
            <span className="inline-flex items-center gap-1.5">
              <Star className="h-4 w-4 fill-[color:var(--secondary)] text-[color:var(--secondary)]" />
              <strong className="text-[color:var(--foreground)]">{business.rating}</strong> Google rating
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Clock className="h-4 w-4 text-[color:var(--accent)]" />
              Open now · 8am–11pm
            </span>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="relative"
        >
          <div className="absolute -inset-4 rounded-[2rem] bg-gradient-to-br from-[color:var(--primary)]/20 to-[color:var(--secondary)]/20 blur-2xl -z-10" />
          <div className="relative rounded-[1.75rem] overflow-hidden border border-[color:var(--border)] shadow-[0_40px_80px_-40px_rgba(140,29,24,0.4)]">
            <img
              src={heroImg}
              alt="Steaming chicken biryani in a copper handi at Biryani House, Jauharabad"
              className="w-full h-[420px] md:h-[520px] object-cover"
              fetchPriority="high"
              width={1600}
              height={1200}
            />
          </div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.5 }}
            className="absolute -bottom-5 left-5 md:left-8 bg-[color:var(--surface)] border border-[color:var(--border)] rounded-2xl px-4 py-3 shadow-xl flex items-center gap-3"
          >
            <div className="h-10 w-10 rounded-full bg-[color:var(--primary)]/10 grid place-items-center text-[color:var(--primary)]">
              <Flame className="h-5 w-5" />
            </div>
            <div className="text-xs">
              <div className="font-semibold text-[color:var(--foreground)]">Cooked fresh daily</div>
              <div className="text-[color:var(--muted-foreground)]">On dum, over slow heat</div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}

function TrustStrip() {
  const items = [
    { icon: Star, label: `${business.rating} Google rating`, sub: "Publicly visible" },
    { icon: Clock, label: "Open daily", sub: "8:00 AM – 11:00 PM" },
    { icon: MapPin, label: "Main Bazar, Jauharabad", sub: "Easy to find on Main Bazar Rd" },
    { icon: Accessibility, label: "Accessible seating", sub: "Wheelchair-friendly indoor area" },
  ];
  return (
    <section className="border-y border-[color:var(--border)] bg-[color:var(--surface)]">
      <div className="container-page py-6 grid grid-cols-2 md:grid-cols-4 gap-4">
        {items.map((it) => (
          <div key={it.label} className="flex items-center gap-3">
            <div className="h-11 w-11 rounded-full bg-[color:var(--primary)]/8 text-[color:var(--primary)] grid place-items-center shrink-0">
              <it.icon className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-semibold text-[color:var(--foreground)] truncate">{it.label}</div>
              <div className="text-xs text-[color:var(--muted-foreground)] truncate">{it.sub}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function SignatureMenu() {
  return (
    <section className="container-page py-20 md:py-28">
      <Reveal>
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <SectionHeader
            eyebrow="The Menu"
            title={<>Signature dishes from <span className="text-[color:var(--primary)]">our handi</span></>}
            subtitle="A short taste of what we cook. Prices shown are editable placeholders — update in one place from the menu file."
          />
          <Link to="/menu" className="btn-ghost self-start md:self-end">
            View full menu <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </Reveal>

      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {featuredDishes.map((d, i) => (
          <Reveal key={d.name} delay={i * 0.05}>
            <article className="card-surface overflow-hidden h-full flex flex-col">
              {d.image && (
                <div className="aspect-[4/3] overflow-hidden">
                  <img
                    src={d.image}
                    alt={d.name}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
              )}
              <div className="p-5 flex flex-col flex-1">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-display text-xl text-[color:var(--foreground)]">{d.name}</h3>
                  <span className="text-[color:var(--primary)] font-semibold whitespace-nowrap">{d.price}</span>
                </div>
                <p className="mt-2 text-sm text-[color:var(--muted-foreground)] leading-relaxed">{d.description}</p>
                {d.editable && <div className="mt-3"><PlaceholderChip>Editable price</PlaceholderChip></div>}
              </div>
            </article>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function WhyUs() {
  const points = [
    { icon: Utensils, title: "Dine-in or takeaway", body: "Eat in our warm dining area or grab it to go — whichever fits your day." },
    { icon: Phone, title: "Order direct by phone", body: "One quick call, no apps, no middlemen. We prep it fresh for pickup." },
    { icon: MapPin, title: "Right on Main Bazar", body: "Easy to find in Jauharabad's Main Bazar — open every day of the week." },
    { icon: Flame, title: "Cooked on dum, daily", body: "Slow, layered biryani with whole spices — the way it's meant to be." },
  ];
  return (
    <section className="bg-[color:var(--surface)] border-y border-[color:var(--border)]">
      <div className="container-page py-20 md:py-24">
        <Reveal>
          <SectionHeader
            center
            eyebrow="Why Biryani House"
            title={<>A local kitchen, done well</>}
            subtitle="Nothing fancy — just honest biryani, warm service and a place that's easy to visit or call."
          />
        </Reveal>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {points.map((p, i) => (
            <Reveal key={p.title} delay={i * 0.06}>
              <div className="card-surface p-6 h-full">
                <div className="h-11 w-11 rounded-xl bg-[color:var(--primary)]/8 text-[color:var(--primary)] grid place-items-center">
                  <p.icon className="h-5 w-5" />
                </div>
                <h3 className="mt-4 font-display text-lg">{p.title}</h3>
                <p className="mt-2 text-sm text-[color:var(--muted-foreground)] leading-relaxed">{p.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function AboutPreview() {
  return (
    <section className="container-page py-20 md:py-28">
      <div className="grid gap-10 lg:grid-cols-2 items-center">
        <Reveal>
          <div className="relative">
            <img
              src={interiorImg}
              alt="Warm dining room at Biryani House in Main Bazar, Jauharabad"
              loading="lazy"
              className="rounded-2xl object-cover w-full h-[420px] border border-[color:var(--border)]"
            />
            <img
              src={spicesImg}
              alt="Saffron and biryani spices"
              loading="lazy"
              className="hidden md:block absolute -bottom-8 -right-6 h-52 w-52 object-cover rounded-2xl border-4 border-[color:var(--background)] shadow-xl"
            />
          </div>
        </Reveal>
        <Reveal delay={0.1}>
          <div className="eyebrow">Our Story</div>
          <h2 className="mt-3 font-display">A neighbourhood biryani spot in Main Bazar</h2>
          <p className="mt-4 text-[color:var(--muted-foreground)] leading-relaxed">
            Biryani House is a local dine-in and takeaway kitchen serving Jauharabad. We keep the menu focused on what we do best — slow-cooked biryani, hearty karahi and fresh sides — and we cook it every day for people who live and work around Main Bazar.
          </p>
          <div className="mt-4 rounded-xl border border-dashed border-[color:var(--border)] bg-[color:var(--surface)] p-4">
            <div className="flex items-center gap-2"><PlaceholderChip>Owner story</PlaceholderChip></div>
            <p className="mt-2 text-sm text-[color:var(--muted-foreground)]">
              [Add a short, verified sentence from the owner about how the restaurant started and what makes the recipe theirs. Keep it warm, local and honest.]
            </p>
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/about" className="btn-ghost">More about us <ArrowRight className="h-4 w-4" /></Link>
            <a href={callHref} className="btn-primary"><Phone className="h-4 w-4" /> Call the kitchen</a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function GalleryPreview() {
  const items = [thaliImg, servingImg, spicesImg, interiorImg];
  return (
    <section className="bg-[color:var(--surface)] border-y border-[color:var(--border)]">
      <div className="container-page py-20 md:py-24">
        <Reveal>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <SectionHeader
              eyebrow="Gallery"
              title="A look at the food and the room"
              subtitle="Real dishes and interior photography. Placeholder images shown — replace with your own approved shots any time."
            />
            <Link to="/gallery" className="btn-ghost self-start md:self-end">
              Open gallery <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </Reveal>
        <div className="mt-10 grid grid-cols-2 md:grid-cols-4 gap-4">
          {items.map((src, i) => (
            <Reveal key={i} delay={i * 0.05}>
              <div className="relative aspect-[4/5] overflow-hidden rounded-xl border border-[color:var(--border)] group">
                <img src={src} alt="Biryani House Jauharabad — food and interior" loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function ReviewsPreview() {
  return (
    <section className="container-page py-20 md:py-28">
      <div className="grid gap-10 lg:grid-cols-[1fr_1.4fr] items-start">
        <Reveal>
          <div className="card-surface p-8 text-center">
            <div className="text-6xl font-display font-bold text-[color:var(--primary)]">{business.rating}</div>
            <div className="mt-2 flex items-center justify-center gap-0.5">
              {[1,2,3,4].map(i => <Star key={i} className="h-5 w-5 fill-[color:var(--secondary)] text-[color:var(--secondary)]" />)}
              <Star className="h-5 w-5 text-[color:var(--secondary)]" />
            </div>
            <div className="mt-3 text-sm text-[color:var(--muted-foreground)]">Google rating (publicly visible)</div>
            <a href={googleReviewsHref} target="_blank" rel="noreferrer" className="btn-secondary mt-6 w-full">
              View on Google
            </a>
          </div>
        </Reveal>
        <div>
          <Reveal>
            <SectionHeader
              eyebrow="What guests say"
              title="Real feedback, honestly shown"
              subtitle="Rating shown as visible on Google. Written review cards below are editable placeholders — replace with approved reviews any time."
            />
          </Reveal>
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            {[1,2,3].map((n) => (
              <Reveal key={n} delay={n * 0.05}>
                <div className="card-surface p-5 h-full">
                  <div className="flex items-center gap-0.5">
                    {[1,2,3,4,5].map(i => <Star key={i} className="h-4 w-4 fill-[color:var(--secondary)] text-[color:var(--secondary)]" />)}
                  </div>
                  <p className="mt-3 text-sm text-[color:var(--foreground)] italic">
                    "[Add a short, approved review quote here. Keep it in the guest's own words.]"
                  </p>
                  <div className="mt-4 flex items-center justify-between text-xs">
                    <span className="font-semibold text-[color:var(--foreground)]">[Guest name]</span>
                    <PlaceholderChip>Editable</PlaceholderChip>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function FaqPreview() {
  return (
    <section className="bg-[color:var(--surface)] border-y border-[color:var(--border)]">
      <div className="container-page py-20 md:py-24">
        <Reveal>
          <SectionHeader
            center
            eyebrow="Good to know"
            title="Frequently asked"
          />
        </Reveal>
        <div className="mt-10 max-w-3xl mx-auto">
          <FaqList items={faqs.slice(0, 5)} />
          <div className="mt-6 text-center">
            <Link to="/faq" className="btn-ghost">All questions <ArrowRight className="h-4 w-4" /></Link>
          </div>
        </div>
      </div>
    </section>
  );
}

function ContactMap() {
  return (
    <section className="container-page py-20 md:py-28">
      <div className="grid gap-8 lg:grid-cols-[1fr_1.2fr] items-start">
        <Reveal>
          <SectionHeader eyebrow="Visit us" title="Come by, or call ahead" />
          <ul className="mt-6 space-y-4 text-[color:var(--foreground)]">
            <li className="flex items-start gap-3">
              <div className="h-10 w-10 rounded-full bg-[color:var(--primary)]/8 grid place-items-center text-[color:var(--primary)] shrink-0"><MapPin className="h-5 w-5" /></div>
              <div>
                <div className="font-semibold">{business.address.line1}</div>
                <div className="text-sm text-[color:var(--muted-foreground)]">{business.address.line2}, {business.address.region}, {business.address.country}</div>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <div className="h-10 w-10 rounded-full bg-[color:var(--primary)]/8 grid place-items-center text-[color:var(--primary)] shrink-0"><Phone className="h-5 w-5" /></div>
              <div>
                <a href={callHref} className="font-semibold hover:text-[color:var(--primary)]">{business.phone}</a>
                <div className="text-sm text-[color:var(--muted-foreground)]">Tap to call</div>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <div className="h-10 w-10 rounded-full bg-[color:var(--primary)]/8 grid place-items-center text-[color:var(--primary)] shrink-0"><Clock className="h-5 w-5" /></div>
              <div>
                <div className="font-semibold">{business.hoursLabel}</div>
                <div className="text-sm text-[color:var(--muted-foreground)]">Same hours every day of the week</div>
              </div>
            </li>
          </ul>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href={callHref} className="btn-primary"><Phone className="h-4 w-4" /> Call to Order</a>
            <a href={directionsHref} target="_blank" rel="noreferrer" className="btn-ghost"><MapPin className="h-4 w-4" /> Get Directions</a>
          </div>
        </Reveal>
        <Reveal delay={0.1}>
          <div className="rounded-2xl overflow-hidden border border-[color:var(--border)] h-[420px] bg-[color:var(--surface)]">
            <iframe
              src={mapEmbedSrc}
              title="Biryani House location on Google Maps"
              className="w-full h-full"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </Reveal>
      </div>
    </section>
  );
}

// Reusable
function FaqList({ items }: { items: { q: string; a: string }[] }) {
  return (
    <div className="divide-y divide-[color:var(--border)] rounded-2xl border border-[color:var(--border)] bg-[color:var(--background)]">
      {items.map((f, i) => <FaqItem key={i} q={f.q} a={f.a} />)}
    </div>
  );
}

function FaqItem({ q, a }: { q: string; a: string }) {
  return (
    <details className="group">
      <summary className="cursor-pointer list-none flex items-center justify-between gap-4 px-5 py-4 text-left">
        <span className="font-semibold text-[color:var(--foreground)]">{q}</span>
        <span className="h-7 w-7 rounded-full border border-[color:var(--border)] grid place-items-center text-[color:var(--primary)] transition-transform group-open:rotate-45">
          <span className="text-lg leading-none">+</span>
        </span>
      </summary>
      <div className="px-5 pb-5 text-sm text-[color:var(--muted-foreground)] leading-relaxed">{a}</div>
    </details>
  );
}

