import { Link } from "@tanstack/react-router";
import { Clock, Facebook, Instagram, MapPin, Phone } from "lucide-react";
import logoMark from "@/assets/logo-mark.png";
import { business, callHref, directionsHref } from "@/lib/business";

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-[color:var(--border)] bg-[color:var(--foreground)] text-[color:var(--background)]">
      <div className="container-page py-14 grid gap-10 md:grid-cols-4">
        <div className="md:col-span-1">
          <div className="flex items-center gap-3">
            <img src={logoMark} alt="" className="h-11 w-11 bg-white/95 rounded-full p-1" />
            <div>
              <div className="font-display text-2xl font-bold text-[color:var(--saffron)]">
                {business.name}
              </div>
              <div className="text-xs tracking-[0.2em] uppercase text-white/60">
                Jauharabad
              </div>
            </div>
          </div>
          <p className="mt-4 text-sm text-white/70 leading-relaxed">
            A local biryani kitchen in Main Bazar — dine in, take away, or call ahead.
          </p>
          <div className="mt-5 flex items-center gap-3">
            <a href="#" aria-label="Instagram" className="h-9 w-9 grid place-items-center rounded-full border border-white/15 hover:bg-white/10 transition">
              <Instagram className="h-4 w-4" />
            </a>
            <a href="#" aria-label="Facebook" className="h-9 w-9 grid place-items-center rounded-full border border-white/15 hover:bg-white/10 transition">
              <Facebook className="h-4 w-4" />
            </a>
          </div>
        </div>

        <div>
          <div className="text-sm font-semibold text-[color:var(--saffron)] uppercase tracking-widest">Visit</div>
          <ul className="mt-4 space-y-2.5 text-sm text-white/80">
            <li className="flex items-start gap-2"><MapPin className="h-4 w-4 mt-0.5 text-[color:var(--saffron)] shrink-0" /><span>{business.address.line1}<br />{business.address.line2}, {business.address.region}</span></li>
            <li><a href={callHref} className="flex items-start gap-2 hover:text-white"><Phone className="h-4 w-4 mt-0.5 text-[color:var(--saffron)] shrink-0" />{business.phone}</a></li>
            <li className="flex items-start gap-2"><Clock className="h-4 w-4 mt-0.5 text-[color:var(--saffron)] shrink-0" />{business.hoursLabel}</li>
          </ul>
        </div>

        <div>
          <div className="text-sm font-semibold text-[color:var(--saffron)] uppercase tracking-widest">Explore</div>
          <ul className="mt-4 space-y-2 text-sm">
            {[
              ["/menu", "Menu"],
              ["/about", "About"],
              ["/gallery", "Gallery"],
              ["/reviews", "Reviews"],
              ["/faq", "FAQ"],
              ["/contact", "Contact"],
            ].map(([to, label]) => (
              <li key={to}>
                <Link to={to} className="text-white/80 hover:text-white transition-colors">{label}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <div className="text-sm font-semibold text-[color:var(--saffron)] uppercase tracking-widest">Take action</div>
          <div className="mt-4 flex flex-col gap-2.5">
            <a href={callHref} className="btn-primary justify-start text-sm">
              <Phone className="h-4 w-4" /> Call to Order
            </a>
            <a href={directionsHref} target="_blank" rel="noreferrer" className="btn-ghost justify-start text-sm border-white/20 text-white hover:bg-white/10">
              <MapPin className="h-4 w-4" /> Get Directions
            </a>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="container-page py-5 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-white/50">
          <span>© {new Date().getFullYear()} {business.name}. All rights reserved.</span>
          <span>Main Bazar Road, Jauharabad · Punjab, Pakistan</span>
        </div>
      </div>
    </footer>
  );
}
