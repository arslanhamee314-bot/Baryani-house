import { Link } from "@tanstack/react-router";
import { Menu, Phone, X } from "lucide-react";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import logoMark from "@/assets/logo-mark.png";
import { business, callHref } from "@/lib/business";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/menu", label: "Menu" },
  { to: "/about", label: "About" },
  { to: "/gallery", label: "Gallery" },
  { to: "/reviews", label: "Reviews" },
  { to: "/faq", label: "FAQ" },
  { to: "/contact", label: "Contact" },
] as const;

export function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  return (
    <header
      className={`sticky top-0 z-40 transition-all duration-300 ${
        scrolled
          ? "bg-[color:var(--surface)]/95 backdrop-blur border-b border-[color:var(--border)] shadow-[0_10px_30px_-20px_rgba(0,0,0,0.25)]"
          : "bg-[color:var(--background)]/80 backdrop-blur-sm border-b border-transparent"
      }`}
    >
      <div className="container-page flex items-center justify-between gap-4 py-3">
        <Link to="/" className="flex items-center gap-2.5 group" aria-label={business.name}>
          <img
            src={logoMark}
            alt=""
            className="h-10 w-10 object-contain"
            width={40}
            height={40}
          />
          <span className="flex flex-col leading-none">
            <span className="font-display text-xl font-bold text-[color:var(--primary)]">
              {business.name}
            </span>
            <span className="text-[10px] tracking-[0.24em] uppercase text-[color:var(--muted-foreground)] mt-0.5">
              Jauharabad
            </span>
          </span>
        </Link>

        <nav className="hidden lg:flex items-center gap-1">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="px-3 py-2 text-sm font-medium text-[color:var(--foreground)]/80 hover:text-[color:var(--primary)] transition-colors relative"
              activeProps={{ className: "text-[color:var(--primary)] font-semibold" }}
              activeOptions={{ exact: item.to === "/" }}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a href={callHref} className="btn-primary hidden sm:inline-flex text-sm py-2.5 px-4">
            <Phone className="h-4 w-4" />
            Call to Order
          </a>
          <button
            className="lg:hidden inline-flex h-10 w-10 items-center justify-center rounded-full border border-[color:var(--border)] text-[color:var(--foreground)]"
            onClick={() => setOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed inset-0 z-50 lg:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="absolute inset-0 bg-black/50" onClick={() => setOpen(false)} />
            <motion.aside
              className="absolute right-0 top-0 h-full w-[85%] max-w-sm bg-[color:var(--surface)] shadow-2xl flex flex-col"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "tween", duration: 0.28 }}
            >
              <div className="flex items-center justify-between p-5 border-b border-[color:var(--border)]">
                <span className="font-display text-lg font-bold text-[color:var(--primary)]">
                  {business.name}
                </span>
                <button
                  className="h-9 w-9 inline-flex items-center justify-center rounded-full hover:bg-[color:var(--muted)]"
                  onClick={() => setOpen(false)}
                  aria-label="Close menu"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <nav className="flex-1 flex flex-col p-3">
                {NAV.map((item) => (
                  <Link
                    key={item.to}
                    to={item.to}
                    onClick={() => setOpen(false)}
                    className="px-4 py-3.5 rounded-lg text-base font-medium text-[color:var(--foreground)] hover:bg-[color:var(--muted)]"
                    activeProps={{ className: "text-[color:var(--primary)] bg-[color:var(--muted)]" }}
                    activeOptions={{ exact: item.to === "/" }}
                  >
                    {item.label}
                  </Link>
                ))}
              </nav>
              <div className="p-5 border-t border-[color:var(--border)]">
                <a href={callHref} className="btn-primary w-full">
                  <Phone className="h-4 w-4" />
                  {business.phone}
                </a>
              </div>
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
