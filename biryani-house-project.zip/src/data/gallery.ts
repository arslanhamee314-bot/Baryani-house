import chicken from "@/assets/dish-chicken-biryani.jpg";
import mutton from "@/assets/dish-mutton-biryani.jpg";
import beef from "@/assets/dish-beef-biryani.jpg";
import karahi from "@/assets/dish-karahi.jpg";
import sides from "@/assets/dish-sides.jpg";
import kheer from "@/assets/dish-kheer.jpg";
import interior from "@/assets/gallery-interior-1.jpg";
import serving from "@/assets/gallery-serving.jpg";
import spices from "@/assets/gallery-spices.jpg";
import thali from "@/assets/gallery-thali.jpg";
import hero from "@/assets/hero-biryani.jpg";

export type GalleryItem = { src: string; alt: string; category: "Food" | "Interior" | "Service" };

export const gallery: GalleryItem[] = [
  { src: hero, alt: "Steaming chicken biryani in a copper handi at Biryani House, Jauharabad", category: "Food" },
  { src: interior, alt: "Warm dining room with wooden tables and brick walls", category: "Interior" },
  { src: serving, alt: "Chef serving fresh basmati rice from a copper handi", category: "Service" },
  { src: chicken, alt: "Close-up plate of chicken biryani", category: "Food" },
  { src: spices, alt: "Saffron strands and whole biryani spices on dark wood", category: "Food" },
  { src: mutton, alt: "Plated mutton biryani with fried onions", category: "Food" },
  { src: thali, alt: "Traditional thali plate with biryani, curry, naan and raita", category: "Food" },
  { src: karahi, alt: "Chicken karahi in a black wok", category: "Food" },
  { src: sides, alt: "Fresh naan bread with raita and green chutney", category: "Food" },
  { src: kheer, alt: "Bowl of Pakistani kheer with pistachios and almonds", category: "Food" },
];
