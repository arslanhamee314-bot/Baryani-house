import chicken from "@/assets/dish-chicken-biryani.jpg";
import mutton from "@/assets/dish-mutton-biryani.jpg";
import beef from "@/assets/dish-beef-biryani.jpg";
import karahi from "@/assets/dish-karahi.jpg";
import sides from "@/assets/dish-sides.jpg";
import kheer from "@/assets/dish-kheer.jpg";

export type Dish = {
  name: string;
  description: string;
  price: string;
  image?: string;
  featured?: boolean;
  editable?: boolean;
};

export const featuredDishes: Dish[] = [
  { name: "Chicken Biryani", description: "Long-grain basmati layered with tender chicken, saffron and slow-cooked masala.", price: "[Rs. ---]", image: chicken, featured: true, editable: true },
  { name: "Mutton Biryani", description: "Aromatic biryani with slow-braised mutton, whole spices and caramelised onions.", price: "[Rs. ---]", image: mutton, featured: true, editable: true },
  { name: "Beef Biryani", description: "Rich, hearty beef biryani cooked over dum with fresh herbs.", price: "[Rs. ---]", image: beef, featured: true, editable: true },
  { name: "Chicken Karahi", description: "Wok-cooked chicken in a tomato and green-chilli masala, finished with coriander.", price: "[Rs. ---]", image: karahi, editable: true },
  { name: "Sides & Breads", description: "Fresh naan, raita, salad and green chutney served alongside every plate.", price: "[Rs. ---]", image: sides, editable: true },
  { name: "Kheer", description: "House-made rice pudding with pistachio, almond and a touch of cardamom.", price: "[Rs. ---]", image: kheer, editable: true },
];

export const menuCategories: { title: string; note?: string; items: Dish[] }[] = [
  {
    title: "Signature Biryani",
    note: "Slow-cooked over dum with basmati rice and whole spices.",
    items: [
      { name: "Chicken Biryani — Regular", description: "Single serving with raita and salan.", price: "[Rs. ---]", editable: true },
      { name: "Chicken Biryani — Family", description: "Serves 3–4. Add-ons available.", price: "[Rs. ---]", editable: true },
      { name: "Mutton Biryani", description: "Tender mutton on the bone, dum cooked.", price: "[Rs. ---]", editable: true },
      { name: "Beef Biryani", description: "Rich beef biryani, house masala.", price: "[Rs. ---]", editable: true },
      { name: "[Add signature item]", description: "[Add short description]", price: "[Rs. ---]", editable: true },
    ],
  },
  {
    title: "Karahi & BBQ",
    note: "Handi and grill items — please call to confirm daily availability.",
    items: [
      { name: "Chicken Karahi", description: "Wok-cooked with tomato and green chilli.", price: "[Rs. ---]", editable: true },
      { name: "Mutton Karahi", description: "Slow-cooked mutton in rich masala.", price: "[Rs. ---]", editable: true },
      { name: "[Add BBQ item]", description: "[e.g. Seekh Kebab, Chicken Tikka]", price: "[Rs. ---]", editable: true },
      { name: "[Add BBQ item]", description: "[Add short description]", price: "[Rs. ---]", editable: true },
    ],
  },
  {
    title: "Sides & Breads",
    items: [
      { name: "Naan", description: "Fresh from the tandoor.", price: "[Rs. ---]", editable: true },
      { name: "Roghni Naan", description: "Enriched naan brushed with butter.", price: "[Rs. ---]", editable: true },
      { name: "Raita", description: "Cool yoghurt with mint.", price: "[Rs. ---]", editable: true },
      { name: "Fresh Salad", description: "Cucumber, tomato, onion, lemon.", price: "[Rs. ---]", editable: true },
    ],
  },
  {
    title: "Drinks & Desserts",
    items: [
      { name: "Fresh Lassi", description: "Sweet or salted.", price: "[Rs. ---]", editable: true },
      { name: "Soft Drinks", description: "Chilled cans and bottles.", price: "[Rs. ---]", editable: true },
      { name: "Kheer", description: "Traditional rice pudding, nutty and lightly sweet.", price: "[Rs. ---]", editable: true },
      { name: "[Add dessert]", description: "[Add short description]", price: "[Rs. ---]", editable: true },
    ],
  },
];
